import React from "react";

function Comment({name, content}){
    return (<div>
    <span>{name}</span>
    <span>---</span>
    <span>{content}</span> <br/>
    </div>);
}

export default Comment