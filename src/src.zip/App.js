import logo from './logo.svg';
import './App.css';
//3. 가져와서 사용할 모듈화된 컴포넌트를 import
import Hello from './Hello';
import Watch from './components/Watch';
import Library from "./components/Library";
import Comments from "./components/Comments";

function App() {

    const color ={
        color : "red",
        background : "black"
    }

    //변수 사용
    // const name = "it";
    const name = ["it", "dev", "friend"];
    const content = ["열공해라", "잘 할거다", "놀자"];


  return (
    // <div className="App">
    //   {/* <header className="App-header">
    //   <h1>Hello React</h1>
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header> */}
    //   {/*4. 컴포넌트 사용 */}
    //   <Hello></Hello>
    // </div>

      //step_02
      //empty fragment(<></>)
      <div style={color} className="hello">
      {/*<Hello class="hello"></Hello>*/}
      {/*   컴포넌트 사이에 변수, text 넣는건 의미가 없다. */}
      {/*<Hello>{name}</Hello>*/}
          {/*<div>{name}</div>*/}
      {/*<Hello></Hello>*/}
      </div>,
    // <Watch></Watch>

      //리액트 컴포넌트와 props
    // <div>
    //   <Library bookName={"React 실습"} bookPrice={15000}></Library>
    //   <Library bookName={"React 실습2"} bookPrice={20000}></Library>
    //   <Library bookName={"React 실습3"} bookPrice={25000}></Library>
    // </div>

    // ver 2
    <div>
      {/*  도서관  */}
      {/*<Library></Library>*/}
    {/*    comments    */}
    <Comments name={name} content={content}></Comments>
    </div>
  );
}


export default App;